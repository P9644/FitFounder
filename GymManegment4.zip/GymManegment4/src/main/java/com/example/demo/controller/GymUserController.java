package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.GymUserDto;
import com.example.demo.dto.LoginRequestDto;
import com.example.demo.dto.LoginResponseDto;
import com.example.demo.service.GymUserService;

@RestController
@RequestMapping("/gymUsers")
public class GymUserController {

    @Autowired
    private GymUserService gymUserService;
    
    @PostMapping("/user")
    public ResponseEntity<String> userRegistration(@RequestBody GymUserDto request) {
        gymUserService.addUser(request);
        return ResponseEntity.ok("User registered successfully");
        
    }
    
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto> loginUser(@RequestBody LoginRequestDto request) {
        try {
            LoginResponseDto response = gymUserService.loginUser(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
        	   e.printStackTrace(); 
            return ResponseEntity.status(401).body(null);  
        }
    }
    
    
    
}
