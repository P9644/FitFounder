package com.example.demo.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dao.GymUsers;
import com.example.demo.dao.Role;
import com.example.demo.dto.GymUserDto;
import com.example.demo.dto.LoginRequestDto;
import com.example.demo.dto.LoginResponseDto;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class GymUserServiceImpl implements GymUserService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

   
    @Override
    @Transactional
    public void addUser(GymUserDto request) {
       
        Role role = roleRepository.findByName(request.getRoleName())
                .orElseThrow(() -> new RuntimeException("Role not found: " + request.getRoleName()));

        
        Set<Role> roles = new HashSet<>();
        roles.add(role);

       
        GymUsers gymUser = new GymUsers();
        gymUser.setEmailId(request.getEmailId());
        gymUser.setFname(request.getFName());
        gymUser.setLname(request.getLName());
        gymUser.setPhoneNo(request.getPhoneNo());
        gymUser.setUserName(request.getUserName());
        gymUser.setPassword(passwordEncoder.encode(request.getPassword())); 
        gymUser.setRoles(roles);

        
        userRepository.save(gymUser);
    }

   
    @Override
    public LoginResponseDto loginUser(LoginRequestDto request) {
        
        Role role = roleRepository.findByName(request.getRoleName())
               .orElseThrow(() -> new RuntimeException("Role not found: " + request.getRoleName()));

      
        GymUsers user = userRepository.findByEmailId(request.getEmailId())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + request.getEmailId()));

       
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password.");
        }

        
        if (user.getRoles().stream().noneMatch(r -> r.getName().equals(request.getRoleName()))) {
            throw new RuntimeException("Role mismatch for user.");
        }

        
        LoginResponseDto response = new LoginResponseDto();
        response.setFName(user.getFname());
        response.setLName(user.getLname());
        response.setPhoneNo(user.getPhoneNo());
        response.setEmailId(user.getEmailId());
        response.setUserName(user.getUserName());
        response.setRoleName(request.getRoleName());

        return response;
    }
}
