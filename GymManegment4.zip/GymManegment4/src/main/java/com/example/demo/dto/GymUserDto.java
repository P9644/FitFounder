package com.example.demo.dto;

import lombok.Data;

@Data
public class GymUserDto {
	
	private String fName;
	private String lName;
	private String phoneNo;
	private String emailId;
	private String userName;
	private String password;
	private String roleName;
}
