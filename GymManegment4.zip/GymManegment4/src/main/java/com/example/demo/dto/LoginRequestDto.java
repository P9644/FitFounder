package com.example.demo.dto;

import lombok.Data;

@Data
public class LoginRequestDto {
    private String emailId;
    private String password;
    private String roleName;
}
