package com.example.demo.dto;

import lombok.Data;

@Data
public class LoginResponseDto {
    private String fName;
    private String lName;
    private String phoneNo;
    private String emailId;
    private String userName;
    private String roleName;
}
