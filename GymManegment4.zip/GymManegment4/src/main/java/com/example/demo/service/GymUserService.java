package com.example.demo.service;

import com.example.demo.dto.GymUserDto;
import com.example.demo.dto.LoginRequestDto;
import com.example.demo.dto.LoginResponseDto;

public interface GymUserService {

	void addUser(GymUserDto request);
	 LoginResponseDto loginUser(LoginRequestDto request);

}
